from pymongo import MongoClient

try:
    client=MongoClient("mongodb+srv://vaishnavi-soni-1210:jahnaviS121095#@vscluster.s4k1y.mongodb.net/shopping?retryWrites=true&w=majority")
    db=client["shopping"]
    coll=db["mobiles"]

    company=input('Enter Mobile Company : ')
    query={}
    query["company"]=company.capitalize()
    #print(query)

    if coll.count_documents(query) > 0:
        for doc in coll.find(query):
            print(' Id: %d \n Model: %s \n Company: %s \n Memory : %s, %s RAM \n Price: Rs. %.2f \n Processor: %s \n Screen Size: %s \n OS: %s \n Rating: %.2f \n' %(doc['id'],doc['model'],doc['company'],doc['rom'], doc['ram'],doc['price'],doc['processor'],doc['screenSize'],doc['os'],doc['rating']))
    else:
        print('No Mobile(document) found in collection with given company!')
except ValueError:
    print(ValueError)

