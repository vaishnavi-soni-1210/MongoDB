from pymongo import MongoClient

try:
    client=MongoClient("mongodb+srv://vaishnavi-soni-1210:jahnaviS121095#@vscluster.s4k1y.mongodb.net/shopping?retryWrites=true&w=majority")
    db=client["shopping"]
    source=db["mobiles"]
    destColl=db["outOfStock"]

    id=int(input('Enter Mobile ID : '))
    query={}
    query["id"]=id
    #print(source.count_documents(query))
    #print(destColl.count_documents(query))

    if source.count_documents(query) > 0:
        for doc in source.find(query):
            docToBeInserted = {}
            docToBeInserted = doc
            source.delete_one(doc)
            destColl.insert_one(docToBeInserted)
            print('Mobile(document) has been removed from "mobiles" collection and added to "outOfStock" collection!')
    else:
        print('No Mobile(document) found in collection with given Id!')
except ValueError:
    print(ValueError)