from pymongo import MongoClient

try:
    client=MongoClient("mongodb+srv://vaishnavi-soni-1210:jahnaviS121095#@vscluster.s4k1y.mongodb.net/shopping?retryWrites=true&w=majority")
    db=client["shopping"]
    coll=db["mobiles"]

    id=int(input('Enter mobile ID to modify : '))
    query={}
    query["id"]=id

    #print(query)
    #print(coll.count_documents(query))

    if coll.count_documents(query) > 0:
        price=float(input('Enter new Price : '))
        queryWithPrice={}
        queryWithPrice["price"]=price

        #print(queryWithPrice)

        updateQuery={"$set":queryWithPrice}

        coll.update_one(query,updateQuery)
        print('Mobile Price is updated successfully!\n')

        print('Updated Mobile details:')
        for doc in coll.find(query):
            print('Id: %d | Model: %s | Memory : %s, %s RAM | Price: Rs. %d \n' %(doc['id'],doc['model'],doc['rom'], doc['ram'],doc['price']))
    else:
        print('No Mobile(document) found in the collection with given Id!')
except ValueError:
    print(ValueError)

