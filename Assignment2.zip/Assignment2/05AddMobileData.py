from pymongo import MongoClient
import random

print('Enter Mobile Data: \n')
id=int(random.randint(1111,9999))
company=input('Enter Company : ')
model=input('Enter Model : ')
processor=input('Enter Processor : ')
screenSize=input('Enter Screen Size : ')
ram=input('Enter RAM : ')
rom=input('Enter ROM(Internal Storage) : ')
os=input('Enter Operating System : ')
price=float(input('Enter Price : '))
rating=float(input('Enter Rating : '))

dic={}
dic["id"]=id
dic["company"]=company.capitalize()
dic["model"]=model.capitalize()
dic["processor"]=processor
dic["screenSize"]=screenSize
dic["ram"]=ram
dic["rom"]=rom
dic["os"]=os.capitalize()
dic["price"]=price
dic["rating"]=rating

try:
    client=MongoClient("mongodb+srv://vaishnavi-soni-1210:jahnaviS121095#@vscluster.s4k1y.mongodb.net/shopping?retryWrites=true&w=majority")
    db=client["shopping"]
    coll=db["mobiles"]

    coll.insert_one(dic)
    print('New mobile added to MongoDB Collection')
except ValueError:
    print(ValueError)