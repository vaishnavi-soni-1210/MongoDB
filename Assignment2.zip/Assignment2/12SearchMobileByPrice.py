from pymongo import MongoClient

try:
    client=MongoClient("mongodb+srv://vaishnavi-soni-1210:jahnaviS121095#@vscluster.s4k1y.mongodb.net/shopping?retryWrites=true&w=majority")
    db=client["shopping"]
    coll=db["mobiles"]

    price=float(input('Enter Price : '))
    innerQuery={}
    innerQuery['$lt']=price
    outerQuery={}
    outerQuery["price"]=innerQuery
    
    #print(outerQuery)
    #print(coll.count_documents(outerQuery))
    # sample query {counter:{$gt:2}}

    if coll.count_documents(outerQuery) > 0:
        for doc in coll.find(outerQuery):
            print('Id: %d | Model: %s | Memory : %s, %s RAM | Price: Rs. %d \n' %(doc['id'],doc['model'],doc['rom'], doc['ram'],doc['price']))
    else:
        print('No Mobile(document) found in collection with price less than Rs. %s!', price)
except ValueError:
    print(ValueError)

