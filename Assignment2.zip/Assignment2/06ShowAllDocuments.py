from pymongo import MongoClient

try:
    client=MongoClient("mongodb+srv://vaishnavi-soni-1210:jahnaviS121095#@vscluster.s4k1y.mongodb.net/shopping?retryWrites=true&w=majority")
    db=client["shopping"]
    coll=db["mobiles"]

    for doc in coll.find():
            print('Id: %d | Model: %s | Company: %s | Memory : %s, %s RAM | Price: Rs. %.2f | Processor: %s | Screen Size: %s | OS: %s | Rating: %.2f | \n' %(doc['id'],doc['model'],doc['company'],doc['rom'], doc['ram'],doc['price'],doc['processor'],doc['screenSize'],doc['os'],doc['rating']))
except ValueError:
    print(ValueError)